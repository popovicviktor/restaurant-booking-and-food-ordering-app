export class Sto{
  id: number=0;
  kapacitet: number=0;
  x: number = 0;
  y: number = 0;
  radius: number = 0;
}
